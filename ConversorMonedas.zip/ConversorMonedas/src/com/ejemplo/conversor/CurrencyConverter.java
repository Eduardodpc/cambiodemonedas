package com.ejemplo.conversor;

import com.google.gson.Gson;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

public class CurrencyConverter {
    private static final String API_URL = "https://api.exchangerate.host/latest";

    public double convertir(String base, String destino, double monto) {
        try {
            String url = API_URL + "?base=" + base + "&symbols=" + destino;

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                System.out.println("Respuesta HTTP inválida: " + response.statusCode());
                return -1;
            }

            Gson gson = new Gson();
            ExchangeRateResponse data = gson.fromJson(response.body(), ExchangeRateResponse.class);

            if (data != null) {
                Map<String, Double> rates = data.getRates();
                if (rates != null && rates.containsKey(destino)) {
                    double tasa = rates.get(destino);
                    return monto * tasa;
                } else {
                    System.out.println("La moneda destino no está disponible en la respuesta.");
                }
            } else {
                System.out.println("No se pudo parsear la respuesta de la API.");
            }
        } catch (Exception e) {
            System.out.println("Error al consultar la API: " + e.getMessage());
        }
        return -1;
    }
}
