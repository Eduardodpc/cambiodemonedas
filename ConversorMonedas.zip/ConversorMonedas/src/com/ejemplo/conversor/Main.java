package com.ejemplo.conversor;

import java.util.Scanner;
import java.util.Set;

public class Main {
    private static final Set<String> MONEDAS_PERMITIDAS = Set.of("ARS", "BOB", "BRL", "CLP", "COP", "USD");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Conversor de Monedas ===");
        System.out.println("Monedas disponibles: " + MONEDAS_PERMITIDAS);

        System.out.print("Ingrese la moneda base: ");
        String base = scanner.nextLine().toUpperCase();
        if (!MONEDAS_PERMITIDAS.contains(base)) {
            System.out.println("Moneda no permitida. Solo se aceptan: " + MONEDAS_PERMITIDAS);
            scanner.close();
            return;
        }

        System.out.print("Ingrese la moneda destino: ");
        String destino = scanner.nextLine().toUpperCase();
        if (!MONEDAS_PERMITIDAS.contains(destino)) {
            System.out.println("Moneda no permitida. Solo se aceptan: " + MONEDAS_PERMITIDAS);
            scanner.close();
            return;
        }

        System.out.print("Ingrese el monto a convertir: ");
        double monto = 0.0;
        try {
            monto = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Monto inválido.");
            scanner.close();
            return;
        }

        CurrencyConverter converter = new CurrencyConverter();
        double convertido = converter.convertir(base, destino, monto);

        if (convertido >= 0) {
            System.out.printf("%.2f %s = %.2f %s%n", monto, base, convertido, destino);
        } else {
            System.out.println("No se pudo realizar la conversión.");
        }

        scanner.close();
    }
}
